#' @author Ivan Jacob Agaloos Pesigan
#'
#' @title strRegression: Structure of Regression
#'
#' @description A collection of functions
#'   related to the mean and covariance structures
#'   of the linear regression model.
#'
#' @docType package
#' @name strRegression
#' @keywords strRegression package
NULL
