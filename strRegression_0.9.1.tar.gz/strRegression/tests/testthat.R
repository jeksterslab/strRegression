library(testthat)
library(strRegression)

test_check("strRegression")
